package qst6;

public class AntSuc {
    int ant;
    int suc;

    public AntSuc(int num){
        ant = num - 1;
        suc = num + 1;
    }
}
